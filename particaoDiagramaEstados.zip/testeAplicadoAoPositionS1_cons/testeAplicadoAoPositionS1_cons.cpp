// testeAplicadoAoPositionS1_cons.cpp : This file contains the 'main' function. Program execution begins and ends there.



/******************************************************* README *****************************************************************
Para que este programa funcione � necess�rio instalar as bibliotecas BOOST
O seguinte link mostra de forma f�cil como o fazer: https://youtu.be/5afpq2TkOHc
Uma vez instaladas dever�o ser adicionadas ao projeto.
O formato do ficheiro de entrada deste programa � devidamente descrito na disserta��o do qual este projeto faz parte
Obrigado pela aten��o!
********************************************************************************************************************************/
#include <iostream>
#include <sstream>
#include <string>
#include <list>
#include <vector>
#include <algorithm>
#include <iterator>

#include <boost/property_tree/ptree.hpp>
using boost::property_tree::ptree;
#include <boost/property_tree/xml_parser.hpp>
#include <boost/foreach.hpp>
#include <boost/optional/optional.hpp>
using namespace std;
using std::to_string;

//Diretoria e ficheiro de entrada
#define XMLPATH1 "c:\\Users\\Afonso\\Desktop\\testesTese\\ficheiroXMLteste\\exemploProf.xml"
#define XMLPATH2 "c:\\Users\\Afonso\\Desktop\\testesTese\\ficheiroXMLteste\\testeValidao.xml"
//Diretoria e ficheiro de sa�da
#define XMLPATHWRITE1 "c:\\Users\\Afonso\\Desktop\\testesTese\\ficheiroXMLteste\\escrito\\teste1.xml"
#define XMLPATHWRITE2 "c:\\Users\\Afonso\\Desktop\\testesTese\\ficheiroXMLteste\\escrito\\teste2.xml"

struct lists{
    list<string> lReg;
    list<string> lInit;
    list<string> lStat;
    list<string> lTrans;
};
struct region {
    string id;
    string history;
    string deepHistory;
    string name;
    int pos_x;
    int pos_y;
    int pos_height;
    int pos_width;
};
struct initial {
    string id;
    int pos_x;
    int pos_y;
};
struct states {
    vector<string> id;
    vector<string> effect;
    vector<string> name;
    vector<int> anotStateOffset_x;
    vector<int> anotStateOffset_y;
    vector<int> pos_x;
    vector<int> pos_y;
    vector<int> pos_height;
    vector<int> pos_width;
};
struct transitions {
    vector<string> id;
    vector<string> evento;
    vector<string> guard;
    vector<string> effect;
    vector<string> source;
    vector<string> destination;
    vector<int> anotOffset_x;
    vector<int> anotOffset_y;
    vector<int> posOrig_x;
    vector<int> posOrig_y;
    vector<int> posEnd_x;
    vector<int> posEnd_y;
};
struct regionPosAlg {
    vector<string> id;
    vector<string> history;
    vector<string> deepHistory;
    vector<string> name;
    vector<int> pos_x;
    vector<int> pos_y;
    vector<int> pos_height;
    vector<int> pos_width;
};
struct initialPosAlg {
    vector<string> id;
    vector<int> pos_x;
    vector<int> pos_y;
};

/*struct statesPosAlg {
    vector<string> id;
    vector<string> effect;
    vector<string> name;
    vector<int> anotStateOffset_x;
    vector<int> anotStateOffset_y;
    vector<int> pos_x;
    vector<int> pos_y;
    vector<int> pos_height;
    vector<int> pos_width;
};
struct transitionsPosAlg {
    vector<string> id;
    vector<string> evento;
    vector<string> guard;
    vector<string> effect;
    vector<string> source;
    vector<string> destination;
    vector<int> anotOffset_x;
    vector<int> anotOffset_y;
    vector<int> posOrig_x;
    vector<int> posOrig_y;
    vector<int> posEnd_x;
    vector<int> posEnd_y;
};*/

lists limpaLista(lists l) {
    l.lInit.clear();
    l.lReg.clear();
    l.lStat.clear();
    l.lTrans.clear();

    return l;
}

region arrumarRegion(lists l) {
    int i=0;
    region regionToStruct;
    list <string> ::iterator it;

    for (it = l.lReg.begin(); it != l.lReg.end(); ++it) {
        if (i == 1)
            regionToStruct.id = *it;
        else
            if (i == 2)
                regionToStruct.history = *it;
            else
                if (i == 3)
                    regionToStruct.deepHistory = *it;
                else
                    if (i == 4)
                        regionToStruct.name = *it;
                    else 
                        if (i == 5)  
                            regionToStruct.pos_x = stoi(*it);
                        else 
                            if (i == 6)
                                regionToStruct.pos_y = stoi(*it);
                            else 
                                if (i == 7)
                                    regionToStruct.pos_height = stoi(*it);
                                else
                                    if(i == 8){
                                        regionToStruct.pos_width = stoi(*it);
                                        i = 0;
                                    }
        i++;
    }
    return regionToStruct;
}

regionPosAlg arrumarRegionsExtra(lists l) {
    int i = 0;
    regionPosAlg regionToStruct;
    list <string> ::iterator it;

    for (it = l.lReg.begin(); it != l.lReg.end(); ++it) {
        if (i == 1)
            regionToStruct.id.push_back(*it);
        else
            if (i == 2)
                regionToStruct.history.push_back(*it);
            else
                if (i == 3)
                    regionToStruct.deepHistory.push_back(*it);
                else
                    if (i == 4)
                        regionToStruct.name.push_back(*it);
                    else
                        if (i == 5){
                            if (*it == "null" || *it == "NULL")
                                regionToStruct.pos_x.push_back(0);
                            else
                                if(*it == "num entre 0 e 99")
                                    regionToStruct.pos_x.push_back(rand()%100); //numero randm de 0 a 99
                                else
                                    regionToStruct.pos_x.push_back(stoi(*it));
                        }
                        else
                            if (i == 6){
                                if (*it == "null" || *it == "NULL")
                                    regionToStruct.pos_y.push_back(0);
                                else
                                    if (*it == "num entre 0 e 99")
                                        regionToStruct.pos_y.push_back(rand() % 100); //numero randm de 0 a 99
                                    else
                                        regionToStruct.pos_y.push_back(stoi(*it));
                            }
                            else
                                if (i == 7){
                                    if (*it == "null" || *it == "NULL")
                                        regionToStruct.pos_height.push_back(0);
                                    else
                                        if (*it == "num entre 0 e 99")
                                            regionToStruct.pos_height.push_back(rand() % 100); //numero randm de 0 a 99
                                        else
                                            regionToStruct.pos_height.push_back(stoi(*it));
                                }
                                else
                                    if (i == 8) {
                                        if (*it == "null" || *it == "NULL")
                                            regionToStruct.pos_width.push_back(0);
                                        else
                                            if (*it == "num entre 0 e 99")
                                                regionToStruct.pos_width.push_back(rand() % 100); //numero randm de 0 a 99
                                            else
                                                regionToStruct.pos_width.push_back(stoi(*it));
                                        i = -1;
                                    }
        i++;
    }
    return regionToStruct;
}

initial arrumarInitial(lists l) {
    int i = 0;
    initial initialToStruct;
    list <string> ::iterator it;

    for (it = l.lInit.begin(); it != l.lInit.end(); ++it) {
        if (i == 1)
            initialToStruct.id = *it;
        else
            if (i == 2)
                initialToStruct.pos_x = stoi(*it);
            else
                if(i==3){
                    initialToStruct.pos_y = stoi(*it);
                    i = 0;
                }
        i++;
    }
    return initialToStruct;
}

initialPosAlg arrumarInitialsExtra(lists l) {
    int i = 0;
    initialPosAlg initialToStruct;
    list <string> ::iterator it;

    for (it = l.lInit.begin(); it != l.lInit.end(); ++it) {
        if (i == 1)
            initialToStruct.id.push_back(*it);
        else
            if (i == 2){
                if (*it == "null" || *it == "NULL")
                    initialToStruct.pos_x.push_back(0);
                else
                    if (*it == "num entre 0 e 99")
                        initialToStruct.pos_x.push_back(rand() % 100); //numero randm de 0 a 99
                    else
                        initialToStruct.pos_x.push_back(stoi(*it));
            }
            else
                if (i == 3) {
                    if (*it == "null" || *it == "NULL")
                        initialToStruct.pos_y.push_back(0);
                    else
                        if (*it == "num entre 0 e 99")
                            initialToStruct.pos_y.push_back(rand() % 100); //numero randm de 0 a 99
                        else
                            initialToStruct.pos_y.push_back(stoi(*it));
                    i = -1;
                }
        i++;
    }
    return initialToStruct;
}

states arrumarStates(lists l) {
    int i = 0;
    states statesToStruct;
    list <string> ::iterator it;

    for (it = l.lStat.begin(); it != l.lStat.end(); ++it) {
        if (i == 1)
            statesToStruct.id.push_back(*it);
        else
            if (i == 2)
                statesToStruct.effect.push_back(*it);
            else
                if (i == 3)
                    statesToStruct.name.push_back(*it);
                else
                    if (i == 4) {
                        if (*it == "null" || *it == "NULL")
                            statesToStruct.anotStateOffset_x.push_back(0);
                        else
                            if(*it=="num entre 0 e 99")
                                statesToStruct.anotStateOffset_x.push_back(rand()%100);
                            else
                                statesToStruct.anotStateOffset_x.push_back(stoi(*it));
                    }
                    else
                        if (i == 5) {
                            if (*it == "null" || *it == "NULL")
                                statesToStruct.anotStateOffset_y.push_back(0);
                            else
                                if (*it == "num entre 0 e 99")
                                    statesToStruct.anotStateOffset_y.push_back(rand() % 100);
                                else
                                    statesToStruct.anotStateOffset_y.push_back(stoi(*it));
                        }
                        else
                            if (i == 6){
                                if (*it == "null" || *it == "NULL")
                                    statesToStruct.pos_x.push_back(0);
                                else
                                    if (*it == "num entre 0 e 99")
                                        statesToStruct.pos_x.push_back(rand() % 100);
                                    else
                                        statesToStruct.pos_x.push_back(stoi(*it));
                            }
                            else
                                if (i == 7){
                                    if (*it == "null" || *it == "NULL")
                                        statesToStruct.pos_y.push_back(0);
                                    else
                                        if (*it == "num entre 0 e 99")
                                            statesToStruct.pos_y.push_back(rand() % 100);
                                        else
                                            statesToStruct.pos_y.push_back(stoi(*it));
                                    }
                                else
                                    if (i == 8){
                                        if (*it == "null" || *it == "NULL")
                                            statesToStruct.pos_height.push_back(0);
                                        else
                                            if (*it == "num entre 0 e 99")
                                                statesToStruct.pos_height.push_back(rand() % 100);
                                            else
                                                statesToStruct.pos_height.push_back(stoi(*it));
                                    }
                                    else
                                        if (i == 9){
                                            if (*it == "null" || *it == "NULL")
                                                statesToStruct.pos_width.push_back(0);
                                            else
                                                if (*it == "num entre 0 e 99")
                                                    statesToStruct.pos_width.push_back(rand() % 100);
                                                else
                                                    statesToStruct.pos_width.push_back(stoi(*it));
                                            i = -1;
                                        }
        i++;
    }
    return statesToStruct;
}

transitions arrumarTransitions(lists l) {
    int i = 0;
    transitions transitionsToStruct;
    list <string> ::iterator it;

    for (it = l.lTrans.begin(); it != l.lTrans.end(); ++it) {

        if (i == 1)
            transitionsToStruct.id.push_back(*it);
        else
            if (i == 2)
                transitionsToStruct.evento.push_back(*it);
            else
                if (i == 3)
                    transitionsToStruct.guard.push_back(*it);
                else
                    if (i == 4)
                        transitionsToStruct.effect.push_back(*it);
                    else
                        if (i == 5)
                            transitionsToStruct.source.push_back(*it);
                        else
                            if (i == 6) 
                                transitionsToStruct.destination.push_back(*it);
                            else
                                if (i == 7) {
                                    if (*it == "null" || *it == "NULL")
                                        transitionsToStruct.anotOffset_x.push_back(0); //ponho a 0 quando � NULL
                                    else
                                        if (*it == "num entre 0 e 99")
                                            transitionsToStruct.anotOffset_x.push_back(rand() % 100);
                                        else
                                            transitionsToStruct.anotOffset_x.push_back(stoi(*it));
                                }
                                else
                                    if (i == 8) {
                                        if (*it == "null" || *it == "NULL")
                                            transitionsToStruct.anotOffset_y.push_back(0); //ponho a 0 quando � NULL
                                        else
                                            if (*it == "num entre 0 e 99")
                                                transitionsToStruct.anotOffset_y.push_back(rand() % 100);
                                            else
                                                transitionsToStruct.anotOffset_y.push_back(stoi(*it));
                                    }
                                    else
                                        if (i == 9) {
                                            if (*it == "null" || *it == "NULL")
                                                transitionsToStruct.posOrig_x.push_back(0); //ponho a 0 quando � NULL
                                            else
                                                if (*it == "num entre 0 e 99")
                                                    transitionsToStruct.posOrig_x.push_back(rand() % 100);
                                                else
                                                    transitionsToStruct.posOrig_x.push_back(stoi(*it));
                                        }
                                        else
                                            if(i==10){
                                                if (*it == "null" || *it == "NULL")
                                                    transitionsToStruct.posOrig_y.push_back(0); //ponho a 0 quando � NULL
                                                else
                                                    if (*it == "num entre 0 e 99")
                                                        transitionsToStruct.posOrig_y.push_back(rand() % 100);
                                                    else
                                                        transitionsToStruct.posOrig_y.push_back(stoi(*it));
                                            }
                                            else
                                                if (i == 11) {
                                                    if (*it == "null" || *it == "NULL")
                                                        transitionsToStruct.posEnd_x.push_back(0); //ponho a 0 quando � NULL
                                                    else
                                                        if (*it == "num entre 0 e 99")
                                                            transitionsToStruct.posEnd_x.push_back(rand() % 100);
                                                        else
                                                            transitionsToStruct.posEnd_x.push_back(stoi(*it));
                                                }
                                                else
                                                    if(i==12){
                                                        if (*it == "null" || *it == "NULL")
                                                            transitionsToStruct.posEnd_y.push_back(0); //ponho a 0 quando � NULL
                                                        else
                                                            if (*it == "num entre 0 e 99")
                                                                transitionsToStruct.posEnd_y.push_back(rand() % 100);
                                                            else
                                                                transitionsToStruct.posEnd_y.push_back(stoi(*it));
                                                        i = -1;
                                                    }
        i++;
    }

    return transitionsToStruct;

    /*switch (i)
{
case 1: transitionsToStruct.id.push_back(*it);
    std::cout << " " << *it << endl;
    i++;
    continue;
case 2: transitionsToStruct.evento.push_back(*it);
    std::cout << " " << *it << endl;
    i++;
    continue;
case 3: transitionsToStruct.guard.push_back(*it);
    std::cout << " " << *it << endl;
    i++;
    continue;
case 4: transitionsToStruct.effect.push_back(*it);
    std::cout << " " << *it << endl;
    i++;
    continue;
case 5: transitionsToStruct.source.push_back(*it);
    std::cout << " " << *it << endl;
    i++;
    continue;
case 6: transitionsToStruct.destination.push_back(*it);
    std::cout << " " << *it << endl;
    i++;
    continue;
case 7:
    if(*it=="null"||*it=="NULL")
        transitionsToStruct.anotOffset_x.push_back(0); //ponho a 0 quando � NULL
    else
        transitionsToStruct.anotOffset_x.push_back(stoi(*it));
    std::cout << " " << *it << endl;
    i++;
    continue;
case 8:
    if (*it == "null" || *it == "NULL")
        transitionsToStruct.anotOffset_y.push_back(0); //ponho a 0 quando � NULL
    else
        transitionsToStruct.anotOffset_y.push_back(stoi(*it));
    std::cout << " " << *it << endl;
    i++;
    continue;
case 9: transitionsToStruct.posOrig_x.push_back(stoi(*it));
    std::cout << " " << *it << endl;
    i++;
    continue;
case 10: transitionsToStruct.posOrig_y.push_back(stoi(*it));
    std::cout << " " << *it << endl;
    i++;
    continue;
case 11: transitionsToStruct.posEnd_x.push_back(stoi(*it));
    std::cout << " " << *it << endl;
    i++;
    continue;
case 12: transitionsToStruct.posEnd_y.push_back(stoi(*it));
    std::cout << " " << *it << endl;
    i = 0;
    continue;
default:
    continue;
}*/
}

lists arrumarListas(list<string> l) {
    lists sortLists;
    list<string> ::iterator it;
    bool foundReg = true, foundInit = false, foundState = false;

    for (it = l.begin(); it != l.end(); ++it) {
        if (*it == "initial") {
            foundReg = false;
            foundInit = true;
        }
        if (*it == "state") {
            foundInit = false;
            foundState = true;
        }
        if (*it == "transition") 
            foundState = false;

        if (foundReg == true)
            sortLists.lReg.push_back(*it);
        else
            if (foundInit == true)
                sortLists.lInit.push_back(*it);
            else
                if (foundState == true)
                    sortLists.lStat.push_back(*it);
                else
                    sortLists.lTrans.push_back(*it);
    }
    return sortLists;
}

//imprime lista de strings
void showList(list<string> l) {  //TENHO DE VERIFICAR SE TUDO ISTO SE APLICA
    list <string> ::iterator it;
    for (it = l.begin(); it != l.end(); ++it) {
        if (*it == "state" || *it == "transition")
            std::cout << '\n';
        std::cout << '\t' << *it << endl;
    }
    std::cout << '\n';
}

list<string> readXMLFile(list<string> l, ptree pt) {
    read_xml(XMLPATH2, pt);
    string idInitial;
    l.clear();

    //percorre elementos da "region"
    BOOST_FOREACH(ptree::value_type & child, pt.get_child("region")) {
        //elemActual = child.first;
        if (child.first == "<xmlattr>") { //imprime atributo da region
            //std::cout << "-Atributo (ID) da region: " << child.second.get<string>("id") << endl;
            l.push_back("region");
            l.push_back(child.second.get<string>("id"));
            l.push_back(child.second.get<string>("history"));
            l.push_back(child.second.get<string>("deep_history"));

        }
        if (child.first == "name") { //imprime nome da region
            //std::cout << "-Nome da region: " << child.second.get<string>("") << endl; //vai buscar conteudo do child.first
            l.push_back(child.second.get<string>(""));
        }
        if (child.first == "position_region") { //imprime posi��o da region
            /*std::cout << "-A position da region: X = " << child.second.get<string>("x") << " e Y = "
                << child.second.get<string>("y") << ", height = " 
                << child.second.get<string>("height") << " e width = "
                << child.second.get<string>("width") << endl;*/
            l.push_back(child.second.get<string>("x"));
            l.push_back(child.second.get<string>("y"));
            l.push_back(child.second.get<string>("height"));
            l.push_back(child.second.get<string>("width"));
        }
        if (child.first == "initial") { //imprime id e posi��o do initial
            idInitial = child.second.get<string>("<xmlattr>.id");
            /*std::cout << "-ID do initial: " << idInitial << " e position: X = "
                << child.second.get<string>("position_initial.x") << " e Y = "
                << child.second.get<string>("position_initial.y") << endl;*/
            l.push_back(child.first);
            l.push_back(idInitial);
            l.push_back(child.second.get<string>("position_initial.x"));
            l.push_back(child.second.get<string>("position_initial.y"));
        }
        if (child.first == "state") { //imprime id, nome e posi��o de cada state
            /*std::cout << "-ID do Estado: " << child.second.get<string>("<xmlattr>.id")
                << " de nome: " << child.second.get<string>("name")  << " de position: X = "
                << child.second.get<string>("position_state.x") << " e Y = "
                << child.second.get<string>("position_state.y") << ", height = "
                << child.second.get<string>("position_state.height") << " e width = "
                << child.second.get<string>("position_state.width") << endl;*/
            l.push_back(child.first);
            l.push_back(child.second.get<string>("<xmlattr>.id"));
            l.push_back(child.second.get<string>("<xmlattr>.effect"));
            l.push_back(child.second.get<string>("name"));
            l.push_back(child.second.get<string>("position_state.<xmlattr>.anotation_off_x"));
            l.push_back(child.second.get<string>("position_state.<xmlattr>.anotation_off_y"));
            l.push_back(child.second.get<string>("position_state.x"));
            l.push_back(child.second.get<string>("position_state.y"));
            l.push_back(child.second.get<string>("position_state.height"));
            l.push_back(child.second.get<string>("position_state.width"));
        }
        if (child.first == "transition") {
            l.push_back(child.first);
            l.push_back(child.second.get<string>("<xmlattr>.id"));
            l.push_back(child.second.get<string>("<xmlattr>.event"));
            l.push_back(child.second.get<string>("<xmlattr>.guard"));
            l.push_back(child.second.get<string>("<xmlattr>.effect"));
            l.push_back(child.second.get<string>("source"));
            l.push_back(child.second.get<string>("destination"));
            l.push_back(child.second.get<string>("position.<xmlattr>.anotation_off_x"));
            l.push_back(child.second.get<string>("position.<xmlattr>.anotation_off_y"));
            l.push_back(child.second.get<string>("position.origin.x"));
            l.push_back(child.second.get<string>("position.origin.y"));
            l.push_back(child.second.get<string>("position.ending.x"));
            l.push_back(child.second.get<string>("position.ending.y"));
            /*if (child.second.get<string>("source") == idInitial)
            std::cout << "-ID da Transition: " << child.second.get<string>("<xmlattr>.id")
            << " de Source: " << child.second.get<string>("source")
            << " de Destination: " << child.second.get<string>("destination")
            << " de position: \n ->origem: X = " << child.second.get<string>("position.origin.x")
            << " e Y = " << child.second.get<string>("position.origin.y")
            << " \n ->ending: X = " << child.second.get<string>("position.ending.x")
            << " e Y = " << child.second.get<string>("position.ending.y") << endl;
            else
                std::cout << "-ID da Transition: " << child.second.get<string>("<xmlattr>.id")
                << " de event: " << child.second.get<string>("<xmlattr>.event")
                << ", de guard: " << child.second.get<string>("<xmlattr>.guard")
                << " e effect: " << child.second.get<string>("<xmlattr>.effect")
                << ", de Source: " << child.second.get<string>("source")
                << " de Destination: " << child.second.get<string>("destination")
                << " de position: \n ->anot_offset: X = " << child.second.get<string>("position.<xmlattr>.anotation_off_x")
                << " e Y = " << child.second.get<string>("position.<xmlattr>.anotation_off_y")
                << " \n ->origem: X = " << child.second.get<string>("position.origin.x")
                << " e Y = " << child.second.get<string>("position.origin.y")
                << " \n ->ending: X = " << child.second.get<string>("position.ending.x")
                << " e Y = " << child.second.get<string>("position.ending.y")
                << endl;*/
        }
        //std::cout << endl;
    }
    return l;
}

vector<string> findCiclos(transitions t) {
    int i = 1, numPercursos = 0, posUltimoOutro;
    bool primeiroDaLista = true, estadoIsolado = true, estadoRepetido=false;
    vector<string> ::iterator it, itDest, itPercursos;
    vector<string> sources, destinations, percursos;
    sources = t.source;     //a posi��o 0 tem o id_initial; s� interessa depois disso
    destinations = t.destination;
    int printSize = std::size(sources);
    int lastBeginPercurso;
    //IMPRESS�O DO QUE SER� TRATADO
    for (int print = 0; print < printSize; print++) {
        std::cout << sources[print] << " ";
    }
    std::cout << endl;
    for (int print = 0; print < printSize; print++) {
        std::cout << destinations[print] << " ";
    }
    std::cout << endl << endl;
    /*cout << sources[0] << " " << sources[1] << " " << sources[2] << " " << sources[3] << " " << sources[4] << " " << sources[5] << " " << sources[6] << " " << sources[7] << " " << sources[8] << endl;
    cout << destinations[0] << " " << destinations[1] << " " << destinations[2] << " " << destinations[3] << " " << destinations[4] << " " << destinations[5] << " " << destinations[6] << " " << destinations[7] << " " << destinations[8] << endl;
    cout << endl;
    cout << sources.size() << endl*/
    //INICIO DO ALGORITMO (FUNCIONA MAS ACHO QUE TEREI DE LIMAR UMAS ARESTAS)
    for (auto it = std::begin(sources)+1; it != std::end(sources); ++it) {
        estadoIsolado = true;
        for (auto itDest = std::begin(destinations) + 1; itDest != std::end(destinations); ++itDest ) {
            if (*it == *itDest){
                estadoIsolado = false;
                break;
            }
        }
        if (estadoIsolado == true) {
            if (primeiroDaLista == false)
                percursos.push_back("outro");
            percursos.push_back(*it);
            percursos.push_back("outro");
            primeiroDaLista = false;
        }
        else{
            if (numPercursos == 0) {
                if (*it == destinations[i - 1])
                    percursos.push_back(*it);
                else
                    if (destinations[i - 1] == percursos.front()) {
                        percursos.push_back(destinations[i - 1]);
                        numPercursos++;
                        percursos.push_back("outro");
                        posUltimoOutro = percursos.size()-1 ;
                        percursos.push_back(*it);
                        //lastBeginPercurso = percursos.size() - 1;
                    }
            }
            else {
                for (int jk = posUltimoOutro; jk < std::size(percursos); jk++) {
                    if (*it == percursos[jk])
                        estadoRepetido = true;
                }
                if (*it == destinations[i - 1] && estadoRepetido==false)
                    percursos.push_back(*it);
                else{
                    for (int k = 0; k < std::size(percursos); k++) {
                        if (destinations[i - 1] == percursos[k]) {
                            percursos.push_back(destinations[i - 1]);
                            percursos.push_back("outro");
                            numPercursos++;
                            percursos.push_back(*it);
                            break;
                        }
                    }
                }
            }
            if (it == std::end(sources) - 1) {
                percursos.push_back(destinations[i]);
                percursos.push_back("fim");
            }
        }
        i++;
        estadoRepetido = false;
    }
    return percursos;

/*if (primeiroDoPercurso == true) {
    percursos.push_back(*it);
    primeiroDoPercurso = false;
}*/
/*for (auto itPercursos = std::begin(percursos); itPercursos != std::end(percursos); ++itPercursos) {
    if (primeiroDoPercurso==true && *it==*itPercursos) {

    }
}
*/
/*for (auto it = std::begin(sources); it != std::end(sources); ++it)
    std::cout << *it << "\n";*/  
/*for (it == sources.begin(); it != sources.end(); ++it) {
    if (*it == sources[0]) {
        percursos.push_back(*it);
        i++;
        std::cout << *it << endl;
    }
    if (*it == destinations[i - 1]) {
        percursos.push_back(*it);
        i++;
        std::cout << *it << endl;
    }
}*/ 
/*
 * Comparing vectors using operator ==
 
    if (vecOfNums1 == vecOfNums2)
    {
        std::cout << "matched" << std::endl;
    }*/
/* Compare all the elements of two vectors
bool result = std::equal(vecOfNums1.begin(), vecOfNums1.end(), vecOfNums2.begin());
if (result)
    std::cout << "Both vectors are equal" << std::endl;*/
}

//ESTA FUN��O TEM DE SER REVISTA
lists defCriarNovasVariaveis(vector<string> v, transitions transitExistentes, states statesExistentes) {
    vector<string> ::iterator it, itAux;
    lists l;
    int numRegionsExtra = 1, numTransicoesExtra = 0, numEstadosExtra = 0, numInitialsExtra = 0;
    int numDeOutros=0, numInicFimDif=0; //incrementa quando inicios do 2� e 3� percurso s�o dif e quando inicio e fim de percurso � dif
    int i = 0, iStateExtra, iPrim, iUltim;
    string ultimoInicio, ultimoFim;
    vector<string> prim2iniciosPercursos, ultimos2finsPercursos; //guarda 2 a 2; 2 depois do "outro", 2 antes do 2� "outro" (repetidamente)
    vector<string> idStatesExtras, idInitialsExtras;
    vector<string> prim2inicEventos, prim2inicGuards, prim2inicEffects, prim2inicNames;
    vector<string> ult2finsEventos, ult2finsGuards, ult2finsEffects, ult2finsNames;
    vector<string> idsTransitExistPorApagar;
    //a �ltima posi��o do idStatesExtras diz respeito ao "waiting-state" da regi�o que j� existia

    for (it = v.begin(); it != v.end(); ++it) { //LEITURA DO VECTOR V (PERCURSOS)
        if (it == v.begin())
            ultimoInicio = *it;
        if (*it == "outro"){
            numRegionsExtra++;
            if (numRegionsExtra > 2){
                ultimos2finsPercursos.push_back(*(it - 2));
                ultimos2finsPercursos.push_back(*(it - 1));
            }
            ultimoFim = *(it - 1);
            ultimoInicio = *(it + 1);
            if (numRegionsExtra > 2 && ((ultimoInicio != ultimoFim) || (*(it + 1) != ultimoInicio)))
                numInicFimDif++;

            prim2iniciosPercursos.push_back(*(it + 1));
            prim2iniciosPercursos.push_back(*(it + 2));
        }
        if (*it == "fim"){
            ultimos2finsPercursos.push_back(*(it - 2));
            ultimos2finsPercursos.push_back(*(it - 1));
        }

        //std::cout << *it << endl;
    }
    numEstadosExtra = numInitialsExtra = numRegionsExtra;
    numDeOutros = numRegionsExtra - 1;

    //devia ser numtransicoesExtra = (prim2iniciosPercursos.size()/2 + ultimos2finsPercursos.size()/2)*2
    if (numDeOutros == 1) // s� aparecer 1 vez "outro"; se n�o houver "outro" nem deveria estar a correr esta fun��o
        numTransicoesExtra = numRegionsExtra*2; // ou seja, 2*2
    else
        numTransicoesExtra = numDeOutros*2 + numInicFimDif; // AINDA N ESTOU CERTO DISTO AQUI ******************** VER DE NOVO ***********************
    
    // P�R INFORMA��O DENTRO DA LISTS
    // cria��o regi�es
    for (i = 0; i <= numRegionsExtra; i++) { //numRegionsExtra = numInitialsExtra
        if(i < numRegionsExtra){
            l.lReg.push_back("region");
            l.lReg.push_back("id_region_extra" + to_string(i)); //id 
            l.lReg.push_back("false"); //history
            l.lReg.push_back("false"); //deep_history
            l.lReg.push_back("region_extra" + to_string(i)); //name
            l.lReg.push_back("num entre 0 e 99"); //pos_x          TENHO QUE VER O QUE VOU FAZER EM RELA��O A MEDIDAS
            l.lReg.push_back("num entre 0 e 99"); //pos_y
            l.lReg.push_back("num entre 0 e 99"); //pos_height
            l.lReg.push_back("num entre 0 e 99"); //pos_width
            //cria��o initials
            l.lInit.push_back("initial");
            l.lInit.push_back("id_initial_extra" + to_string(i)); //id
            idInitialsExtras.push_back(l.lInit.back());
            l.lInit.push_back("num entre 0 e 99"); //pos_x
            l.lInit.push_back("num entre 0 e 99"); //pos_y
        }
        // cria��o de estados (= numEstadosExtra + 1; incluindo o "estado que cont�m as regi�es extra"
        // o �ltimo estado extra aqui criado vai ser o "Estado dos Estados"
        l.lStat.push_back("state");
        l.lStat.push_back("id_state_extra" + to_string(i)); //id
        idStatesExtras.push_back(l.lStat.back());
        l.lStat.push_back("NULL"); //effect
        l.lStat.push_back("state_extra"+ to_string(i)); //name
        l.lStat.push_back("NULL"); //anotStateOffset_x
        l.lStat.push_back("NULL"); //anotStateOffset_y
        l.lStat.push_back("num entre 0 e 99"); //pos_x
        l.lStat.push_back("num entre 0 e 99"); //pos_y
        l.lStat.push_back("num entre 0 e 99"); //pos_height
        l.lStat.push_back("num entre 0 e 99"); //pos_width
    }

    l.lInit.push_back("TransitionsApagar"); //marco na lista das initials para adicionar os ids das transitions existentes que s�o para apagar
    //buscar dados de transitions existentes
    iPrim = 0; iUltim = 0;
    int k;
    for (int j = 0; j < transitExistentes.id.size(); j++) {
        /*if (i == std::size(prim2iniciosPercursos))
            break; //s� para n haver a hip�tese de ele tentar aceder a mem�ria que n existe*/
        if(iPrim<std::size(prim2iniciosPercursos))
            if (prim2iniciosPercursos[iPrim] == transitExistentes.source[j] && prim2iniciosPercursos[iPrim + 1] == transitExistentes.destination[j]) {
                prim2inicEventos.push_back(transitExistentes.evento[j]);
                prim2inicGuards.push_back(transitExistentes.guard[j]);
                prim2inicEffects.push_back(transitExistentes.effect[j]);
                idsTransitExistPorApagar.push_back(transitExistentes.id[j]);
                for (k = 0; k < statesExistentes.id.size(); k++) {
                    if (statesExistentes.id[k] == transitExistentes.source[j]) {
                        prim2inicNames.push_back(statesExistentes.name[k]);
                        l.lInit.push_back(transitExistentes.id[j]);
                    }
                        
                }

                iPrim += 2;
            }
        if(iUltim<std::size(ultimos2finsPercursos))
            if (ultimos2finsPercursos[iUltim] == transitExistentes.source[j] && ultimos2finsPercursos[iUltim + 1] == transitExistentes.destination[j]) {
                ult2finsEventos.push_back(transitExistentes.evento[j]);
                ult2finsGuards.push_back(transitExistentes.guard[j]);
                ult2finsEffects.push_back(transitExistentes.effect[j]);
                idsTransitExistPorApagar.push_back(transitExistentes.id[j]);
                for (k = 0; k < statesExistentes.id.size(); k++) {
                    if (statesExistentes.id[k] == transitExistentes.source[j]){
                        ult2finsNames.push_back(statesExistentes.name[k]);
                        l.lInit.push_back(transitExistentes.id[j]);
                    }
                }

                iUltim += 2;
            }
    }
    //l.lInit.push_back("fimTransitionsApagar"); //marco na lista das initials para adicionar os ids das transitions existentes que s�o para apagar

    //cria��o de transi��es (+ transicoes initial-state)
    numTransicoesExtra += numInitialsExtra;
    iStateExtra = 0; //estado extra que vai ficar na primeira regi�o (o �nico que n tem initial ligado a si)
    iPrim = 0; iUltim = 0;
    bool semaforo = true, semafPrimUlt=true;
    for (i = 0; i < numTransicoesExtra; i++) {
        // j� existe 1 transi��o initial-estado que liga ao primeiro estado; faltam o de Estado de estados e os das restantes novas regioes
        // encontrar dentro do percurso que id's ainda se repetem ap�s o "outro" e lig�-los aos novos estados extra
        // n�o esquecer dos eventos e guards que j� existiam
        l.lTrans.push_back("transition");
        l.lTrans.push_back("id_transition_extra"+to_string(i)); //id
        if (i < numInitialsExtra) {
            l.lTrans.push_back("NULL"); //evento
            l.lTrans.push_back("NULL"); //guard
            l.lTrans.push_back("NULL"); //effect
            l.lTrans.push_back(idInitialsExtras[i]); //source (initials_extras)
            l.lTrans.push_back(idStatesExtras[i+1]); //destination (states_extras); state0 n�o tem initial
        }
        else {
            if(semafPrimUlt == true){
                if (semaforo==true) { //estado extra � destination
                    l.lTrans.push_back(prim2inicEventos[iPrim]); //evento
                    l.lTrans.push_back(prim2inicGuards[iPrim]); //guard
                    l.lTrans.push_back("NULL"); //effect
                    l.lTrans.push_back(prim2iniciosPercursos[iPrim]); //source
                    l.lTrans.push_back(idStatesExtras[iStateExtra]); //destination (estado extra)
                    semaforo = false;
                }
                else{ //estado extra � source
                    l.lTrans.push_back(prim2inicEventos[iPrim]); //evento
                    l.lTrans.push_back("in_"+prim2inicNames[iStateExtra]); //guard
                    l.lTrans.push_back(prim2inicEffects[iPrim]); //effect
                    l.lTrans.push_back(idStatesExtras[iStateExtra+1]); //source (estado extra); H� SITUA��ES EM QUE CHEGA AO ESTADO EXTRA N�O DESEJADO **VER DISSO**
                    l.lTrans.push_back(prim2iniciosPercursos[iPrim+1]); //destination 
                    semaforo = true;
                    semafPrimUlt = false;
                    iPrim += 2;
                }
            }
            else {
                if (semaforo == true) { //estado extra � destination
                    l.lTrans.push_back(ult2finsEventos[iUltim]); //evento
                    l.lTrans.push_back(ult2finsGuards[iUltim]); //guard
                    l.lTrans.push_back("NULL"); //effect
                    l.lTrans.push_back(ultimos2finsPercursos[iUltim]); //source
                    l.lTrans.push_back(idStatesExtras[iStateExtra + 1]); //destination (estado extra); desta vez � "de tr�s para a frente"
                    semaforo = false;
                }
                else {
                    l.lTrans.push_back(ult2finsEventos[iUltim]); //evento
                    l.lTrans.push_back("in_"+ult2finsNames[iStateExtra]); //guard
                    l.lTrans.push_back(ult2finsEffects[iUltim]); //effect
                    l.lTrans.push_back(idStatesExtras[iStateExtra]); //source (estado extra)
                    l.lTrans.push_back(ultimos2finsPercursos[iUltim+1]); //destination
                    semaforo = true;
                    semafPrimUlt = true;
                    iUltim += 2;
                    iStateExtra++;
                }

            }
            
        }
        l.lTrans.push_back("NULL"); //anotOffset_x
        l.lTrans.push_back("NULL"); //anotOffset_y
        l.lTrans.push_back("num entre 0 e 99"); //posOrig_x
        l.lTrans.push_back("num entre 0 e 99"); //posOrig_y
        l.lTrans.push_back("num entre 0 e 99"); //posEnd_x
        l.lTrans.push_back("num entre 0 e 99"); //posEnd_y
    }
    return l;
}

transitions anularTransitionsUnused(transitions t, lists l) { //os ids das transitions que deixam de ser usados passam a "NULL"
    list <string> ::iterator it;
    vector <string> ids;
    bool sem = false;

    for (it = l.lInit.begin(); it != l.lInit.end(); ++it) {
        if(sem==true){
            ids.push_back(*it);
            //cout << *it << endl;
        }
        if (*it == "TransitionsApagar") 
            sem = true;
    }

    for (int i = 0; i < t.id.size(); i++) {
        for (int j = 0; j < ids.size(); j++) {
            if (t.id[i] == ids[j])
                t.id[i] = "NULL";
        }
        //cout << t.id[i] << endl;
    }
    return t;
}

lists tirarInfoTransDosInitials(lists l) {
    list <string> ::iterator it, itAux;

    for (it = l.lInit.begin(); it != l.lInit.end(); ++it) {
        if (*it == "TransitionsApagar"){
            itAux = it;
            break;
        }
    }
    l.lInit.erase(itAux, l.lInit.end());

    return l;
}

ptree criacaoSubRegion(region regBeg, initial initBeg, states statBeg, transitions tranBeg, regionPosAlg regNew, initialPosAlg initNew,
    states statNew, transitions tranNew, vector<string> idStatComReg, int numReg) {
    //fazer o mesmo que fiz onde esta fun��o foi chamada s� que com maior n�mero de elementos
    ptree nodeRegion, nodeInitial, nodeState, nodeTransition;
    vector<string> idTransVerif;
    bool jaExiste=false;

    if (numReg == 0) {
        nodeRegion.add("<xmlattr>.id", regBeg.id);
        nodeRegion.add("<xmlattr>.history", regBeg.history);
        nodeRegion.add("<xmlattr>.deep_history", regBeg.deepHistory);
        nodeRegion.add("name", regBeg.name);
        nodeRegion.add("position_region.x", regBeg.pos_x);
        nodeRegion.add("position_region.y", regBeg.pos_y);
        nodeRegion.add("position_region.height", regBeg.pos_height);
        nodeRegion.add("position_region.width", regBeg.pos_width);
        //info initial
        nodeInitial.add("<xmlattr>.id", initBeg.id);
        nodeInitial.add("position_initial.x", initBeg.pos_x);
        nodeInitial.add("position_initial.y", initBeg.pos_y);
        nodeRegion.add_child("initial", nodeInitial);
    }
    else {
        nodeRegion.add("<xmlattr>.id", regNew.id[numReg-1]); //-1 para come�ar na posi��o 0 deste vector
        nodeRegion.add("<xmlattr>.history", regNew.history[numReg - 1]);
        nodeRegion.add("<xmlattr>.deep_history", regNew.deepHistory[numReg - 1]);
        nodeRegion.add("name", regNew.name[numReg - 1]);
        nodeRegion.add("position_region.x", regNew.pos_x[numReg - 1]);
        nodeRegion.add("position_region.y", regNew.pos_y[numReg - 1]);
        nodeRegion.add("position_region.height", regNew.pos_height[numReg - 1]);
        nodeRegion.add("position_region.width", regNew.pos_width[numReg - 1]);
        //info initial
        nodeInitial.add("<xmlattr>.id", initNew.id[numReg - 1]);
        nodeInitial.add("position_initial.x", initNew.pos_x[numReg - 1]);
        nodeInitial.add("position_initial.y", initNew.pos_y[numReg - 1]);
        nodeRegion.add_child("initial", nodeInitial);
    }
    //info dos states
    for (int i = 0; i < statBeg.id.size(); i++) { 
        for (int j = 0; j < idStatComReg.size(); j += 2) {
            if (statBeg.id[i] == idStatComReg[j] && stoi(idStatComReg[j + 1]) == numReg) {
                nodeState.add("<xmlattr>.id", statBeg.id[i]);
                nodeState.add("<xmlattr>.effect", statBeg.effect[i]);
                nodeState.add("name", statBeg.name[i]);
                nodeState.add("position_state.<xmlattr>.anotation_off_x", statBeg.anotStateOffset_x[i]);
                nodeState.add("position_state.<xmlattr>.anotation_off_y", statBeg.anotStateOffset_y[i]);
                nodeState.add("position_state.x", statBeg.pos_x[i]);
                nodeState.add("position_state.y", statBeg.pos_y[i]);
                nodeState.add("position_state.height", statBeg.pos_height[i]);
                nodeState.add("position_state.width", statBeg.pos_width[i]);
                nodeRegion.add_child("state", nodeState); //tenho de fazer isto o n� de vezes de cada state
                nodeState.clear();
            }
        }
    }
    //O WAITING-STATE DE CADA REGI�O CORRESPONDE AO DA POSI��O DE numReg
    nodeState.add("<xmlattr>.id", statNew.id[numReg]);
    nodeState.add("<xmlattr>.effect", statNew.effect[numReg]);
    nodeState.add("name", statNew.name[numReg]);
    nodeState.add("position_state.<xmlattr>.anotation_off_x", statNew.anotStateOffset_x[numReg]);
    nodeState.add("position_state.<xmlattr>.anotation_off_y", statNew.anotStateOffset_y[numReg]);
    nodeState.add("position_state.x", statNew.pos_x[numReg]);
    nodeState.add("position_state.y", statNew.pos_y[numReg]);
    nodeState.add("position_state.height", statNew.pos_height[numReg]);
    nodeState.add("position_state.width", statNew.pos_width[numReg]);
    nodeRegion.add_child("state", nodeState); //tenho de fazer isto o n� de vezes de cada state
    
    //fica so a faltar as transitions; se o source ou o destination corresponde a um estado da region, ent�o bota (usar o vector idStatComReg que tem essa informa��o)
    for (int i = 0; i < tranBeg.id.size(); i++) {
        for (int j = 0; j < idStatComReg.size(); j += 2) {
            if (idTransVerif.empty() == false) {
                for(int k=0; k<idTransVerif.size(); k++){
                    if (tranBeg.id[i] == idTransVerif[k])
                        jaExiste = true;
                }
                if (jaExiste == false && tranBeg.id[i] != "NULL" && (tranBeg.source[i] == idStatComReg[j] || tranBeg.destination[i] == idStatComReg[j]) && stoi(idStatComReg[j + 1]) == numReg) {
                    
                    idTransVerif.push_back(tranBeg.id[i]);

                    nodeTransition.add("<xmlattr>.id", tranBeg.id[i]);
                    nodeTransition.add("<xmlattr>.event", tranBeg.evento[i]);
                    nodeTransition.add("<xmlattr>.guard", tranBeg.guard[i]);
                    nodeTransition.add("<xmlattr>.effect", tranBeg.effect[i]);
                    nodeTransition.add("source", tranBeg.source[i]);
                    nodeTransition.add("destination", tranBeg.destination[i]);
                    nodeTransition.add("position.<xmlattr>.anotation_off_x", tranBeg.anotOffset_x[i]);
                    nodeTransition.add("position.<xmlattr>.anotation_off_y", tranBeg.anotOffset_y[i]);
                    nodeTransition.add("position.origin.x", tranBeg.posOrig_x[i]);
                    nodeTransition.add("position.origin.y", tranBeg.posOrig_y[i]);
                    nodeTransition.add("position.ending.x", tranBeg.posEnd_x[i]);
                    nodeTransition.add("position.ending.y", tranBeg.posEnd_y[i]);
                    nodeRegion.add_child("transition", nodeTransition);
                    nodeTransition.clear();
                }
                else
                    if(jaExiste==true)
                        jaExiste = false;
            }
            else {
                if(tranBeg.id[i] != "NULL" && (tranBeg.source[i] == idStatComReg[j] || tranBeg.destination[i] == idStatComReg[j]) && stoi(idStatComReg[j + 1]) == numReg){
                    idTransVerif.push_back(tranBeg.id[i]);

                    nodeTransition.add("<xmlattr>.id", tranBeg.id[i]);
                    nodeTransition.add("<xmlattr>.event", tranBeg.evento[i]);
                    nodeTransition.add("<xmlattr>.guard", tranBeg.guard[i]);
                    nodeTransition.add("<xmlattr>.effect", tranBeg.effect[i]);
                    nodeTransition.add("source", tranBeg.source[i]);
                    nodeTransition.add("destination", tranBeg.destination[i]);
                    nodeTransition.add("position.<xmlattr>.anotation_off_x", tranBeg.anotOffset_x[i]);
                    nodeTransition.add("position.<xmlattr>.anotation_off_y", tranBeg.anotOffset_y[i]);
                    nodeTransition.add("position.origin.x", tranBeg.posOrig_x[i]);
                    nodeTransition.add("position.origin.y", tranBeg.posOrig_y[i]);
                    nodeTransition.add("position.ending.x", tranBeg.posEnd_x[i]);
                    nodeTransition.add("position.ending.y", tranBeg.posEnd_y[i]);
                    nodeRegion.add_child("transition", nodeTransition);
                    nodeTransition.clear();
                }
            }
        } // tenho de fazer o controlo do que j� guardei para n repetir info; o mesmo no ciclo abaixo
    }
    
    idTransVerif.clear();

    for (int i = 0; i < tranNew.id.size(); i++) {
        for (int j = 0; j < idStatComReg.size(); j += 2) {
            if (idTransVerif.empty() == false) {
                for (int k = 0; k < idTransVerif.size(); k++) {
                    if (tranNew.id[i] == idTransVerif[k])
                        jaExiste = true;
                }
                if (jaExiste == false && (tranNew.source[i] == idStatComReg[j] || tranNew.destination[i] == idStatComReg[j]) && stoi(idStatComReg[j + 1]) == numReg) {

                    idTransVerif.push_back(tranNew.id[i]);

                    nodeTransition.add("<xmlattr>.id", tranNew.id[i]);
                    nodeTransition.add("<xmlattr>.event", tranNew.evento[i]);
                    nodeTransition.add("<xmlattr>.guard", tranNew.guard[i]);
                    nodeTransition.add("<xmlattr>.effect", tranNew.effect[i]);
                    nodeTransition.add("source", tranNew.source[i]);
                    nodeTransition.add("destination", tranNew.destination[i]);
                    nodeTransition.add("position.<xmlattr>.anotation_off_x", tranNew.anotOffset_x[i]);
                    nodeTransition.add("position.<xmlattr>.anotation_off_y", tranNew.anotOffset_y[i]);
                    nodeTransition.add("position.origin.x", tranNew.posOrig_x[i]);
                    nodeTransition.add("position.origin.y", tranNew.posOrig_y[i]);
                    nodeTransition.add("position.ending.x", tranNew.posEnd_x[i]);
                    nodeTransition.add("position.ending.y", tranNew.posEnd_y[i]);
                    nodeRegion.add_child("transition", nodeTransition);
                    nodeTransition.clear();
                }
                else
                    if (jaExiste == true)
                        jaExiste = false;
            }
            else {
                if((tranNew.source[i] == idStatComReg[j] || tranNew.destination[i] == idStatComReg[j]) && stoi(idStatComReg[j + 1]) == numReg){
                    idTransVerif.push_back(tranNew.id[i]);

                    nodeTransition.add("<xmlattr>.id", tranNew.id[i]);
                    nodeTransition.add("<xmlattr>.event", tranNew.evento[i]);
                    nodeTransition.add("<xmlattr>.guard", tranNew.guard[i]);
                    nodeTransition.add("<xmlattr>.effect", tranNew.effect[i]);
                    nodeTransition.add("source", tranNew.source[i]);
                    nodeTransition.add("destination", tranNew.destination[i]);
                    nodeTransition.add("position.<xmlattr>.anotation_off_x", tranNew.anotOffset_x[i]);
                    nodeTransition.add("position.<xmlattr>.anotation_off_y", tranNew.anotOffset_y[i]);
                    nodeTransition.add("position.origin.x", tranNew.posOrig_x[i]);
                    nodeTransition.add("position.origin.y", tranNew.posOrig_y[i]);
                    nodeTransition.add("position.ending.x", tranNew.posEnd_x[i]);
                    nodeTransition.add("position.ending.y", tranNew.posEnd_y[i]);
                    nodeRegion.add_child("transition", nodeTransition);
                    nodeTransition.clear();
                }
            }
        }
    }

    return nodeRegion;
}

vector<string> criacaoVectorStatesComRegions(vector<string> percursos, states statesLidos, states statesCriados) {
    vector<string> statesComRegions; //vector com informa��o 2 a 2: states seguido do id da regi�o. n tem em conta a regi�o-"m�e"
    int outroCount = 0; //vai corresponder � regi�o; se for 0 diz respeito � regi�o que j� existia
    bool jaExiste = false;

    for (int j = 0; j < statesLidos.id.size(); j++) {
        for (int i = 0; i < percursos.size(); i++) {
            if (percursos[i] == "outro")
                outroCount++;
            else{
                if (statesLidos.id[j] == percursos[i]) {
                    if (statesComRegions.empty()==false) {
                        for (int k = 0; k < statesComRegions.size(); k++) {
                            if (statesLidos.id[j] == statesComRegions[k])
                                jaExiste = true;
                        }
                        if (jaExiste == false) {
                            statesComRegions.push_back(statesLidos.id[j]);
                            statesComRegions.push_back(to_string(outroCount));
                        }
                        else
                            jaExiste = false;
                    }
                    else{
                        statesComRegions.push_back(statesLidos.id[j]);
                        statesComRegions.push_back(to_string(outroCount));
                    }
                }
                else
                    if (percursos[i] == "fim")
                        outroCount = 0;
            }
        }
    }
    //outroCount = 0; 
    for (int j = 0; j < statesCriados.id.size(); j++) {
        statesComRegions.push_back(statesCriados.id[j]);
        statesComRegions.push_back(to_string(j));
    }
    return statesComRegions;
}

void writeXMLFile(region region_beg, initial initial_beg, states states_beg, transitions transitions_beg, 
    regionPosAlg regions_built, initialPosAlg initials_built, states states_built, transitions transitions_built, vector<string> percursos, ptree pt) {
    //criar as regioes e seus initials n devem ser problema
    //tenho de saber � partida qual a regi�o de cada estado; as transi��es podem ir por verifica��o da source/destination
    vector<string> idsStatesComSuasRegions; //vector com informa��o 2 a 2: states seguido do id da regi�o.

    ptree nodeRegion, nodeInitial, nodeState, nodeTransition, nodeNewRegion;
    // nas fun��es do property tree, o "add" adiciona enquanto que o "put" "escreve por cima"
    idsStatesComSuasRegions = criacaoVectorStatesComRegions(percursos, states_beg, states_built);
    for (int i = 0; i < idsStatesComSuasRegions.size(); i+=2) {
        cout << idsStatesComSuasRegions[i]<< "  "<< idsStatesComSuasRegions[i+1] << endl;
    }
    // o property-tree � definido de baixo para cima, ou seja, a region que engloba tudo estar� no fim 


    //info transition da regi�o das regi�es; corresponde � transition cujo source � o �ltimo dos que foram criados
    for (int i = 0; i < transitions_built.id.size(); i++) {
        if (transitions_built.source[i] == initials_built.id.back()) {
            nodeTransition.add("<xmlattr>.id", transitions_built.id[i]);
            nodeTransition.add("<xmlattr>.event", transitions_built.evento[i]);
            nodeTransition.add("<xmlattr>.guard", transitions_built.guard[i]);
            nodeTransition.add("<xmlattr>.effect", transitions_built.effect[i]);
            nodeTransition.add("source", transitions_built.source[i]);
            nodeTransition.add("destination", transitions_built.destination[i]);
            nodeTransition.add("position.<xmlattr>.anotation_off_x", transitions_built.anotOffset_x[i]);
            nodeTransition.add("position.<xmlattr>.anotation_off_y", transitions_built.anotOffset_y[i]);
            nodeTransition.add("position.origin.x", transitions_built.posOrig_x[i]);
            nodeTransition.add("position.origin.y", transitions_built.posOrig_y[i]);
            nodeTransition.add("position.ending.x", transitions_built.posEnd_x[i]);
            nodeTransition.add("position.ending.y", transitions_built.posEnd_y[i]);
        }
    }
    //info state que conter� �s v�rias regi�es
    nodeState.add("<xmlattr>.id", states_built.id.back());
    nodeState.add("<xmlattr>.effect", states_built.effect.back());
    nodeState.add("name", states_built.name.back());
    nodeState.add("position_state.<xmlattr>.anotation_off_x", states_built.anotStateOffset_x.back());
    nodeState.add("position_state.<xmlattr>.anotation_off_y", states_built.anotStateOffset_y.back());
    nodeState.add("position_state.x", states_built.pos_x.back());
    nodeState.add("position_state.y", states_built.pos_y.back());
    nodeState.add("position_state.height", states_built.pos_height.back());
    nodeState.add("position_state.width", states_built.pos_width.back());
    //aqui ser�o "inscritas" as regi�es presentes no estado dos estados
    for (int i = 0; i < regions_built.id.size(); i++) { //devia ser -1 porque uma das regi�es j� foi usada mas falta a que j� existia
        nodeNewRegion = criacaoSubRegion(region_beg, initial_beg, states_beg, transitions_beg, regions_built, initials_built, states_built, 
            transitions_built, idsStatesComSuasRegions, i);
        nodeState.add_child("region", nodeNewRegion);
    }
    //info initial da regiao raiz
    nodeInitial.add("<xmlattr>.id", initials_built.id.back());
    nodeInitial.add("position_initial.x", initials_built.pos_x.back());
    nodeInitial.add("position_initial.y", initials_built.pos_y.back());
    //info regiao raiz
    nodeRegion.add("<xmlattr>.id", regions_built.id.back());
    nodeRegion.add("<xmlattr>.history", regions_built.history.back());
    nodeRegion.add("<xmlattr>.deep_history", regions_built.deepHistory.back());
    nodeRegion.add("name", regions_built.name.back());
    nodeRegion.add("position_region.x", regions_built.pos_x.back());
    nodeRegion.add("position_region.y", regions_built.pos_y.back());
    nodeRegion.add("position_region.height", regions_built.pos_height.back());
    nodeRegion.add("position_region.width", regions_built.pos_width.back());
    //designa��o dos principais elementos da regi�o das regi�es
    nodeRegion.add_child("initial", nodeInitial);
    nodeRegion.add_child("state", nodeState);
    nodeRegion.add_child("transition", nodeTransition);
    //agrega tudo o que foi feito acima
    pt.add_child("region", nodeRegion);

    write_xml(XMLPATHWRITE2, pt);
    //write_xml(XMLPATHWRITE1, pt, std::locale(), xml_writer_make_settings< std::string >(' ', 4));
}

int main(){
    vector<string> ::iterator it;
	ptree pt;
	list<string> listaPrimeiraLeitura;
    lists sortedLists;
    region sortedRegion;
    initial sortedInitial;
    states sortedStates, sortedExtraStates;
    transitions sortedTransitions, sortedExtraTransitions;
    vector<string> percursos;
    regionPosAlg sortedExtraRegion;
    initialPosAlg sortedExtraInitial;

    listaPrimeiraLeitura = readXMLFile(listaPrimeiraLeitura, pt);
    //showList(listaPrimeiraLeitura);
    sortedLists = arrumarListas(listaPrimeiraLeitura);
    //showList(sortedLists.lReg);
    //showList(sortedLists.lInit);
    //showList(sortedLists.lStat);
    //showList(sortedLists.lTrans);
    sortedRegion = arrumarRegion(sortedLists);
    sortedInitial = arrumarInitial(sortedLists);
    sortedStates = arrumarStates(sortedLists);
    sortedTransitions = arrumarTransitions(sortedLists); 
    /*std::cout << "Teste: " << sortedStates.id[0] << " " << sortedStates.id[1]
        << " " << sortedStates.id[2] << " " << sortedStates.id[3] << " " << sortedStates.id[4] 
        << " " << sortedStates.id[5] << " " << sortedStates.id[6] << endl;
    std::cout << "Teste: " << sortedTransitions.id[0] << " " << sortedTransitions.id[1]
        << " " << sortedTransitions.id[2] << " " << sortedTransitions.id[3] << " " << sortedTransitions.id[4]
        << " " << sortedTransitions.id[5] << " " << sortedTransitions.id[6] << endl;*/
  
    percursos = findCiclos(sortedTransitions); 
    for (it = percursos.begin(); it != percursos.end(); ++it) {
        std::cout << *it << "  ";
        if (it == percursos.end() - 1)
            std::cout << endl;
    }
    sortedLists = limpaLista(sortedLists);

    sortedLists = defCriarNovasVariaveis(percursos, sortedTransitions, sortedStates); //esta fun��o � uma aut�ntica salganhada (EM MANUTEN��O)
    /*showList(sortedLists.lReg);
    showList(sortedLists.lInit);
    showList(sortedLists.lStat);
    showList(sortedLists.lTrans);*/

    sortedTransitions = anularTransitionsUnused(sortedTransitions, sortedLists); //fun��o para apagar as transi��es desnecess�rias (antigas); EDIT: N�o apaguei, igualei o id a "NULL" das que n vou mais usar
    //showList(sortedLists.lInit);
    sortedLists = tirarInfoTransDosInitials(sortedLists);
    //showList(sortedLists.lInit);
    sortedExtraRegion = arrumarRegionsExtra(sortedLists);
    sortedExtraInitial = arrumarInitialsExtra(sortedLists);
    sortedExtraStates = arrumarStates(sortedLists);
    sortedExtraTransitions = arrumarTransitions(sortedLists);

    std::cout << endl;
    //MONTAGEM DO FICHEIRO XML
    writeXMLFile(sortedRegion, sortedInitial, sortedStates, sortedTransitions, sortedExtraRegion, sortedExtraInitial,
        sortedExtraStates, sortedExtraTransitions, percursos, pt);

    return 0;
}


//std::cout << "Hello World!\n";
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file

